<!DOCTYPE HTML>
<html>
<body>
<?php
for($i=5;$i>=1;$i--)
{
	for($j=$i;$j>=1;$j--)
	{echo "*";}
echo "<br>";
	
}

?>
</body>
</html>