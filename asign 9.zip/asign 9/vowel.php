<html>
<body>
<?php
$x=$_POST["ch"];
switch($x)
{
	case "a":
		echo "a";
		break;
	case "e":
		echo "e";
		break;
	case "i":
		echo "i";
		break;
	case "o":
		echo "o";
		break;
	case "u":
		echo "u";
		break;
	default:
		echo "Consonant";
}

?>
</body>
</html>