<!DOCTYPE HTML>
<html>
<body>
<?php
$week=array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturnday");
for($i=0;$i<7;$i++)
{
	echo $week[$i]."<br>";
	
}

?>
</body>
</html>