<!DOCTYPE HTML>
<html>
<body>
<?php
function writename($name)
{
	echo "my name is $name <br>";
	
}
writename("Ramchandra");
$name1="narendra";
writename($name1);
?>
</body>
</html>