<!DOCTYPE HTML>
<html>
<body>
<?php
$x=12;
$y=10;
echo "numbers are $x and $y<br>";
echo "addition ".($x+$y)."<br>";
echo "multiplication ".($x*$y)."<br>";
echo "subtraction ".($x-$y)."<br>";
echo "division ".($x/$y)."<br>";


?>
</body>
</html>