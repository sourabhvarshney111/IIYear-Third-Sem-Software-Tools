<html>
<body>
<?php
$x=$_POST["num"];
if($x%2==0)
{echo "$x is even Number";}
else
{echo "$x is odd number";}

?>
</body>
</html>