<!DOCTYPE HTML>
<html>
<body>
<form action="oddeven.php" method="post">
Enter The number : <input type="number" name="num">
<input type="submit" value="submit">
</form>
</body>
</html>