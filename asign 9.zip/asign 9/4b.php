<!DOCTYPE HTML>
<html>
<body>
<?php
$x=[[1,1],[4,5]];
$y=[[6,8],[3,3]];
$sum=[[0,0],[0,0]];
for($i=0;$i<2;$i++)
{
	for($j=0;$j<2;$j++)
	{
		$sum[$i][$j]=$x[$i][$j]+$y[$i][$j];
		echo $sum[$i][$j]."  ";
	}
	echo "<br>";
	
	
}

?>
</body>
</html>