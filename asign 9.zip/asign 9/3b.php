<!DOCTYPE HTML>
<html>
<body>
<?php
$x=10;
$y=11;
echo "numbers are $x and $y<br>";
if($x>$y)
{echo "$x is greater than $y";}
else if($x<$y)
{echo "$y is greater than $x";}
else
{echo "$x is equal to $y";}

?>
</body>
</html>