<!DOCTYPE HTML>
<html>
<body>
<?php
$x=array("one","two","Three");
for($i=0;$i<3;$i++)
{
	echo $x[$i]."<br>";
	
}

?>
</body>
</html>