<!DOCTYPE HTML>
<html>
<body>
<?php
function writename2($firstname,$fathersname,$lname)
{
	echo "my name is $firstname $lname<br>";
	echo "my Father's name is $fathersname $lname<br>";
	
}
$lname="Modi";
$first="Narendra";
$fa="Damodardas";
writename2($first,$fa,$lname);
?>
</body>
</html>