<!DOCTYPE HTML>
<html>
<body>
<form action="vowel.php" method="post">
Enter The Character : <input type="text" name="ch">
<input type="submit" value="submit">
</form>
</body>
</html>